<?php
echo md5('thisisasecret');

//pass123
//thisisasecret

?>
